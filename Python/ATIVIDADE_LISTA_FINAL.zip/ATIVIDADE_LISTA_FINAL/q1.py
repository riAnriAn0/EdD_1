numeros = []

for i in range(5):
    numero = int(input('Numero:'))
    numeros.append(numero)

for num in numeros:
    print(f"Numero: {num}")