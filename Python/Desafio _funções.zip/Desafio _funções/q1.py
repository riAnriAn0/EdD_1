def soma(a, b, c):
    return a +b +c

valor1 = int(input("Digite o valor 1: "))
valor2 = int(input("Digite o valor 2: "))
valor3 = int(input("Digite o valor 3: "))

result = soma(valor1,valor2, valor3)

print(f"Soma dos valores : {result}")