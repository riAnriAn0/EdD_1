def media(a, b, c):
    return (a+ b+c)/3

print(media(10,10,10))